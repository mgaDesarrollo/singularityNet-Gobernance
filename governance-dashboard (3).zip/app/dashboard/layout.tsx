import type React from "react"
import { SidebarNav } from "@/components/sidebar-nav"
import { UserNav } from "@/components/user-nav"
import { PrivateRoute } from "@/components/private-route"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <PrivateRoute>
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-10 border-b bg-background">
          <div className="flex h-16 items-center justify-between px-4 md:px-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold">
                SN
              </div>
              <span className="font-bold">SingularityNET Governance</span>
            </div>
            <UserNav />
          </div>
        </header>
        <div className="flex flex-1">
          <SidebarNav />
          <main className="flex-1 p-4 md:p-6">{children}</main>
        </div>
      </div>
    </PrivateRoute>
  )
}
